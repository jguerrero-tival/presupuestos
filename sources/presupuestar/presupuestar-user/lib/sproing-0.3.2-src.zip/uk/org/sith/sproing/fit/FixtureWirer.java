package uk.org.sith.sproing.fit;

import org.springframework.beans.factory.config.AutowireCapableBeanFactory;

import uk.org.sith.sproing.spring.ApplicationWirer;

/**
 * Wires up the given {@link SpringWirableFixture} FitNesse fixture into spring. If a spring bean factory has not yet
 * been created from the files given in the getPaths() method, that is created first<br/>
 * The fixture needs to implement {@link SpringWirableFixture} and extend your chosen FitNesse fixture. It is wired
 * using the {@link AutowireCapableBeanFactory.AUTOWIRE_BY_NAME} strategy - it needs to do this to work properly with
 * FitNesse, so your fixtures need to have setter methods with the same names as the beans you want to wire up<br/>
 * You need to create a subclass of this class and implement the getPaths() method to return the paths of the spring
 * application context files you want to wire up<br/>
 * For example:
 * 
 * <pre>
   public class YourAppFixtureWirer extends AbstractFixtureWirer {
   
      public String[] getPaths() {
   
         return new String[] {
                  "classpath:fitnesseApplicationContext.xml",
                  "classpath:applicationContext.xml"};
      }
   
   } 
 * </pre>
 * 
 * To wire up your fixture, all you need do is create a default constructor (or setUp() method if using a fixture that
 * has one) and create a new instance of your overridden {@link FixtureWirer} class<br/>
 * For example, using YourAppFixtureWirer in the above example:
 * 
 * <pre>
   public class TestFixture extends ColumnFixture implements SpringWirableFixture {
   
      public TestFixture() {
         new YourAppFixtureWirer().wire(this);
      }
      
   }
 * </pre>
 * 
 * FitNesse will call the default constructor, wiring up your fixture with the bean factory. Provided you have defined
 * public setter methods for any spring dependencies your fixture needs, and called them the same names as described
 * above, spring will inject these at runtime. You can then write your fixture methods as normal
 * 
 * @author Antony Lees
 */
public abstract class FixtureWirer extends ApplicationWirer {

   /**
    * Wires up the given {@link SpringWirableFixture} FitNesse fixture into spring. If a spring bean factory has not yet
    * been created from the files given in the getPaths() method, that is created first<br/>
    * The fixture needs to implement {@link SpringWirableFixture} and extend your chosen FitNesse fixture. It is wired
    * using the {@link AutowireCapableBeanFactory.AUTOWIRE_BY_NAME} strategy - it needs to do this to work properly with
    * FitNesse, so your fixtures need to have setter methods with the same names as the beans you want to wire up<br/>
    * 
    * @param fixture the fixture to wire up
    */
   public void wire(SpringWirableFixture fixture) {
      super.wire(fixture);
   }
}
