package uk.org.sith.sproing.spring;

/**
 * Marks classes as being wirable into spring. Implementing classes must define a string array containing the paths to
 * the spring application context files needing to be wired into the bean factory
 * 
 * @author Antony Lees
 */
public interface SpringWirable {

   /**
    * Defines the application context paths that need to be wired in order to create the bean factory
    * 
    * @return an array of strings that contain the paths to the spring application context files
    */
   public String[] getPaths();

}