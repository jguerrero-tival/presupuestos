package uk.org.sith.sproing.spring;

/**
 * Runtime exception used when an object cannot be wired into spring
 * 
 * @author Antony Lees
 */
public class SpringWiringException extends RuntimeException {

   private static final long serialVersionUID = 7989962513430814210L;

   /**
    * Creates a new exception with the given message
    * 
    * @param message the message for this exception
    */
   public SpringWiringException(String message) {
      super(message);
   }

   /**
    * Creates a new exception with the given message and cause exception
    * 
    * @param message the message for this exception
    * @param cause the cause of this exception
    */
   public SpringWiringException(String message, Throwable cause) {
      super(message, cause);
   }

}
