package uk.org.sith.sproing.spring;

public interface SinglePathSpringWirable extends SpringWirable {

   public String getPath();

}
