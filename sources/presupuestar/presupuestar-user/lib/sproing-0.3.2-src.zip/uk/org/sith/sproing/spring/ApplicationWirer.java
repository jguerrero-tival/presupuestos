package uk.org.sith.sproing.spring;

public abstract class ApplicationWirer implements SpringWirable {

   /**
    * Wires up the given object into spring. If a spring bean factory has not yet been created from the files given in
    * the getPaths() method, that is created first. Currently only AUTOWIRE_BY_NAME is implemented
    * 
    * @param fixture the fixture to wire up
    */
   public void wire(Object object) {
      SpringWirer.wireApplicationContext(this);
      SpringWirer.wireBean(object);
   }

}
