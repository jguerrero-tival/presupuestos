package uk.org.sith.sproing.fit;

/**
 * Marks FitNesse fixtures as being able to wired into spring using sproing
 * 
 * @author Antony Lees
 */
public interface SpringWirableFixture {

}
