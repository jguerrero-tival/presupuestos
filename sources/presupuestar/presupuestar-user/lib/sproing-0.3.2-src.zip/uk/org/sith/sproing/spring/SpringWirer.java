package uk.org.sith.sproing.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Deals with spring wiring by creating the bean factory from the paths to the application context files, and can wire
 * new beans into the existing application context
 * 
 * @author Antony Lees
 */
public abstract class SpringWirer {

   static final String SPROING_APPLICATION_CONTEXT = "sproingApplicationContext.xml";

   /**
    * Creates a spring bean factory from the paths returned from the getPaths() method of the given
    * {@link SpringWirable} instance
    * 
    * @param wirable the object defining the paths to the spring application context files
    */
   public static void wireApplicationContext(SpringWirable wirable) {

      // if the application context doesn't exist yet
      if (ApplicationContextProvider.getApplicationContext() == null) {
         // add the sproing application context
         String[] newPaths = addSproingContext(wirable.getPaths());
         // create the application context - the ApplicationContextProvider will pick this up automagically
         new ClassPathXmlApplicationContext(newPaths);
      }

      // TODO else add it?

   }

   /**
    * Wires the given object into the existing application context
    * 
    * @param object the object to wire
    */
   public static void wireBean(Object object) {

      SpringBeanFactoryProvider.autowireByName(object);

   }

   /**
    * Adds the sproing application context to the list of paths
    * 
    * @param paths the user-given paths
    * @return the paths with the sproing one added
    */
   static String[] addSproingContext(String[] paths) {

      String[] newPaths = new String[paths.length + 1];

      newPaths[0] = SPROING_APPLICATION_CONTEXT;

      int index = 1;
      for (String string : paths) {
         newPaths[index] = string;
         index++;
      }

      return newPaths;

   }

}
