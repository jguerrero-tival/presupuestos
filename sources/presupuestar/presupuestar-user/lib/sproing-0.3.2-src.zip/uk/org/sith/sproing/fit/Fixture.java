package uk.org.sith.sproing.fit;

// TODO
public @interface Fixture {

}
